set -e
make -C src clean
